# Lavori svolti

- Terminata implementazione holder
- Continuata la documentazione

# Problemi riscontrati e soluzioni

Nessun problema riscontrato

# Punto della situazione rispetto alla pianificazione

Sono in linea con la pianificazione

# Programma dimassima per la prossima giornata

Consegna della documentazione, dunque terminarla a casa (specialmente fare design consuntivo visto dall'alto, basta con Sketchup 3D)