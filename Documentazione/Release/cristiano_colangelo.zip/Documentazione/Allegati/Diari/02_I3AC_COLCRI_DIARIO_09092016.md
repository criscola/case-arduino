# Lavori svolti

Ci è stata spiegata la valutazione degi progetti e il life cycle di un progetto, infine abbiamo provveduto a creare delle domande per la futura intervista
al committente per quanto riguarda il nostro prossimo progetto dell'holder per Arduino.

# Problemi riscontrati e soluzioni

Nessun problema riscontrato

# Punto della situazione rispetto alla pianificazione

Non è ancora stato pianificato nulla.

# Programma di massima per la prossima giornata

Non è ancora stato pianificato nulla
