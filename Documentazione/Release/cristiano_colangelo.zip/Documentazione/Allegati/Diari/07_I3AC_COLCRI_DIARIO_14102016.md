# Lavori svolti

- Continuazione del capitolo di progettazione della doc
- Inizio del capitolo di implementazione della doc

# Problemi riscontrati e soluzioni

Non mi sono stati recapitati gli oggetti che avevo richiesto (nemmeno uno all'infuori dei materiali base come colla legno e carta vetrata). Questo non mi ha permesso di completare l'implementazione dell'Holder. Inoltre le lame del traforo di continuavano a rompere di continuo...

# Punto della situazione rispetto alla pianificazione

Sono in linea con la pianificazione

# Programma dimassima per la prossima giornata

Terminare tutto il rimanente, implementazione e documentazione.