# Lavori svolti

8.20 - 11.35: Introduzione al Modulo 306, presentazione del primo progetto, versioning e GitHub.
13.15 - 16.00: Download, installazione e configurazione di Git e SourceTree

# Problemi riscontrati e soluzioni

Ho riscontrato un problema di timeout della connessione verso la porta 443 su Git, non ho ancora trovato una soluzione al problema

# Punto della situazione rispetto alla pianificazione

Non è ancora stato pianificato nulla.

# Programma di massima per la prossima giornata

Non è ancora stato pianificato nulla.