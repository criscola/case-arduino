# Lavori svolti

- Prime 2 ore teoria sulla progettazione e Gantt
- Controllo del docente sui requisiti
- Disegno su sketchup
- Ricerca informazioni su software per la creazione dei Gantt

# Problemi riscontrati e soluzioni

Nessun problema riscontrato.

# Punto della situazione rispetto alla pianificazione

Redazione del disegno e del Gantt 

# Programma di massima per la prossima giornata

Finire il disegno in SketchUp e terminare la documentazione