# Lavori svolti

- Teoria sui requisiti
- Intervista al cliente
- Redazione delle specifiche
- Redazione di parte della documentazione (progettazione)

# Problemi riscontrati e soluzioni

Ho riscontrato un piccolo problema con la rete del CPT che come al solito fa acqua da tutte le parti, c'era un problema con il DNS ma cambiando da proxy a 10.20.0.1 il software di git è riuscito a collegarsi.

# Punto della situazione rispetto alla pianificazione

Non è ancora stato pianificato nulla.

# Programma dimassima per la prossima giornata

Test 1 e Gantt