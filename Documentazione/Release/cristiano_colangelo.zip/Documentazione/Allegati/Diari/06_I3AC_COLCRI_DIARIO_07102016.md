# Lavori svolti

- Teoria su implementazione
- Discussione sui componenti del progetto
- Rifinitura disegno su Sketchup
- Continuazione parte progettazione della doc

# Problemi riscontrati e soluzioni

Nessun problema riscontrato

# Punto della situazione rispetto alla pianificazione

Indietro con il programma, assolutamente finire Gantt e costi della progettazione

# Programma dimassima per la prossima giornata

Finire Gantt e costi della progettazione e tagliare i pezzi di compensato per il progetto