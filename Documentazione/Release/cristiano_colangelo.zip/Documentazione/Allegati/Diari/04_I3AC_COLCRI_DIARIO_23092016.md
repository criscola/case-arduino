# Lavori svolti

- Prime 2 ore test
- Resanti 4 ore teoria use-case e esercizio pratico corretto in classe

# Problemi riscontrati e soluzioni

Nessun problema riscontrato.

# Punto della situazione rispetto alla pianificazione

Pianificazione - Use case

# Programma di massima per la prossima giornata

Sconosciuto